# DMDD_Group_16

Restaurant Management Site link:
https://sites.google.com/view/dmddrestaurantmanagement/home?authuser=0
